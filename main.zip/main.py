from os import system   
import subprocess
import requests              
import webbrowser       
import getpass  
mytitle = "Клонер - by d3f0ltik"                                
system("title "+mytitle)  
import psutil             
import time               
import sys                
import discord            
import asyncio            
import colorama           
from colorama import Fore, init, Style                          
import platform           
from serverclone import Clone      
intents = discord.Intents.all()                                  
client = discord.Client(intents=intents) 
os = platform.system()    
if os == "Windows":       
    system("cls")         
else:                     
    system("clear")       
    print(chr(27) + "[2J")


#CHECK #CHECK #CHECK #CHECK
hwid = subprocess.check_output('wmic csproduct get uuid').decode().split('\n')[1].strip()
r = requests.get('https://pastebin.com/raw/6Xe3KAdw')

try:
    if hwid in r.text:
        print (Fore.GREEN + 'Подписка активна осталось: 9999 дней')
        time.sleep(1)
        system("cls")
        pass
    else:
        print(Fore.GREEN + f'Проверка подписки...')
        time.sleep(1)
        exit()
except:
    print(Fore.RED + f'У тебя нету подписки!\n')
    print(Fore.YELLOW + f'ХВИД >> {hwid}')
    time.sleep(3)
    exit()
#CHECK #CHECK #CHECK #CHECK





import os
papka = ('C:\\d3f0ltik')
os.makedirs(papka, exist_ok=True)

file_path = "C:\\d3f0ltik\\infocln.dat"

if os.path.isfile(file_path):
    time.sleep(0.1)
else:
    webbrowser.open_new('https://bio.d3f4ult.ru')
    webbrowser.open_new('https://discord.gg/ekDrs7txmZ') #100 peoples
    try:
        with open(file_path, 'w') as file:
            file.write(f"bio_first = true \ndiscord_first = true")
            print('Файл infocln.dat в папке C:\\d3f0ltik был создан')
    except OSError as e:
        print(f"Ошибка при записи в файл: {e}")

import requests
import subprocess
import sys
from time import sleep


import requests
import subprocess
import sys
from time import sleep


class Update():
    def __init__(self):
        self.version = '0.2'
        self.github = 'https://raw.githubusercontent.com/m1lka1337/clonerdiscord/main/update.py'
        self.zipfile = ''
        self.update_checker()

    def update_checker(self):
        code = requests.get(self.github).text
        if "self.version = '0.2'" in code:
            print('Ваша версия актуальна!')
            time.sleep(1)
            pass
        else:
            print('''
                    ███╗   ██╗███████╗██╗    ██╗    ██╗   ██╗██████╗ ██████╗  █████╗ ████████╗███████╗██╗
                    ████╗  ██║██╔════╝██║    ██║    ██║   ██║██╔══██╗██╔══██╗██╔══██╗╚══██╔══╝██╔════╝██║
                    ██╔██╗ ██║█████╗  ██║ █╗ ██║    ██║   ██║██████╔╝██║  ██║███████║   ██║   █████╗  ██║
                    ██║╚██╗██║██╔══╝  ██║███╗██║    ██║   ██║██╔═══╝ ██║  ██║██╔══██║   ██║   ██╔══╝  ╚═╝
                    ██║ ╚████║███████╗╚███╔███╔╝    ╚██████╔╝██║     ██████╔╝██║  ██║   ██║   ███████╗██╗
                    ╚═╝  ╚═══╝╚══════╝ ╚══╝╚══╝      ╚═════╝ ╚═╝     ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝
                                      Ваша версия устарела выберите вариант ниже''')
            choice = input('\nХотите обновить? (да/нет): ')
            if choice.lower() == 'да':
                print('Скачивание обновления...')
                new_version_source = requests.get(self.zipfile)
                with open("Update.zip", 'wb')as zipfile:
                    zipfile.write(new_version_source.content)

                subprocess.Popen([sys.executable, 'updater.py'])

                sys.exit(2)
            if choice.lower() == 'нет':
                sys.exit(0)


if __name__ == '__main__':
    Update()




print(f"""{Fore.MAGENTA}
    ██████╗ ██████╗ ███████╗ ██████╗ ██╗  ████████╗██╗██╗  ██╗     ██████╗██╗      ██████╗ ███╗   ██╗███████╗██████╗ 
    ██╔══██╗╚════██╗██╔════╝██╔═████╗██║  ╚══██╔══╝██║██║ ██╔╝    ██╔════╝██║     ██╔═══██╗████╗  ██║██╔════╝██╔══██╗
    ██║  ██║ █████╔╝█████╗  ██║██╔██║██║     ██║   ██║█████╔╝     ██║     ██║     ██║   ██║██╔██╗ ██║█████╗  ██████╔╝
    ██║  ██║ ╚═══██╗██╔══╝  ████╔╝██║██║     ██║   ██║██╔═██╗     ██║     ██║     ██║   ██║██║╚██╗██║██╔══╝  ██╔══██╗
    ██████╔╝██████╔╝██║     ╚██████╔╝███████╗██║   ██║██║  ██╗    ╚██████╗███████╗╚██████╔╝██║ ╚████║███████╗██║  ██║
    ╚═════╝ ╚═════╝ ╚═╝      ╚═════╝ ╚══════╝╚═╝   ╚═╝╚═╝  ╚═╝     ╚═════╝╚══════╝ ╚═════╝ ╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝
 
{Style.RESET_ALL}
  {Fore.CYAN}                                      Поддержка (дискорд): d3f4ult1337\n                                       https://funpay.com/users/12156406/{Style.RESET_ALL}
        """)              
token = input(Fore.YELLOW + f'1. Введите токен аккаунта:\n >> ')               
guild_s = input(Fore.LIGHTMAGENTA_EX + '2. Id сервера который нужно скопировать:\n >> ')
guild = input(Fore.GREEN + '3. Id сервера куда нужно вставить:\n >> ')        
input_guild_id = guild_s  
output_guild_id = guild   
token = token             
                          
                          
print("  ")               
print("  ")               
                          
@client.event             
async def on_ready():     
    extrem_map = {}       
    print(f"Вход с аккаунта : {client.user}")                   
    print("Клонирование началось | By d3f0ltik")               
    guild_from = client.get_guild(int(input_guild_id))          
    guild_to = client.get_guild(int(output_guild_id))           
    await Clone.guild_edit(guild_to, guild_from)                
    await Clone.roles_delete(guild_to)                          
    await Clone.channels_delete(guild_to)                       
    await Clone.roles_create(guild_to, guild_from)              
    await Clone.categories_create(guild_to, guild_from)         
    await Clone.channels_create(guild_to, guild_from)           
    print(f"""{Fore.BLUE}


    ██████╗ ██████╗ ███████╗ ██████╗ ██╗  ████████╗██╗██╗  ██╗     ██████╗██╗      ██████╗ ███╗   ██╗███████╗██████╗ 
    ██╔══██╗╚════██╗██╔════╝██╔═████╗██║  ╚══██╔══╝██║██║ ██╔╝    ██╔════╝██║     ██╔═══██╗████╗  ██║██╔════╝██╔══██╗
    ██║  ██║ █████╔╝█████╗  ██║██╔██║██║     ██║   ██║█████╔╝     ██║     ██║     ██║   ██║██╔██╗ ██║█████╗  ██████╔╝
    ██║  ██║ ╚═══██╗██╔══╝  ████╔╝██║██║     ██║   ██║██╔═██╗     ██║     ██║     ██║   ██║██║╚██╗██║██╔══╝  ██╔══██╗
    ██████╔╝██████╔╝██║     ╚██████╔╝███████╗██║   ██║██║  ██╗    ╚██████╗███████╗╚██████╔╝██║ ╚████║███████╗██║  ██║
    ╚═════╝ ╚═════╝ ╚═╝      ╚═════╝ ╚══════╝╚═╝   ╚═╝╚═╝  ╚═╝     ╚═════╝╚══════╝ ╚═════╝ ╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝
{Fore.CYAN}                                        Поддержка (дискорд): d3f4ult1337\n                                       https://funpay.com/users/12156406/{Style.RESET_ALL}

    {Style.RESET_ALL}""") 
    await asyncio.sleep(5)
    await client.close()  
                                      
client.run(token, bot=False)