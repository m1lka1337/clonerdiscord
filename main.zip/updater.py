import os
import shutil
import subprocess
from zipfile import ZipFile


def main():
    if not os.path.exists('Update.zip'):
        print('Update.zip не найден')
        return

    print("Извлекаю Update.zip...")
    try:
        with ZipFile('Update.zip', 'r') as zip_ref:
            zip_ref.extractall()
            temp_folder = zip_ref.filelist[0].filename.removesuffix('/')
    except Exception as e:
        print(f"Не смог извлечь Update.zip: {e}")
        return
    print("Перенос файлов...")
    try:
        for file in os.listdir(temp_folder):
            target_file_path = os.path.join(os.getcwd(), file)
            if os.path.exists(target_file_path):
                if os.path.isdir(target_file_path):
                    shutil.rmtree(target_file_path)
                else:
                    os.remove(target_file_path)
            shutil.move(os.path.join(temp_folder, file), os.getcwd())
    except Exception as e:
        print(f"Не смог перенести файлы: {e}")
        return
    finally:
        print("Удаляю...")
        shutil.rmtree(temp_folder)
        os.remove('Update.zip')
        print("Обновление успешно.")
        print("Перезапускаюсь...")
        subprocess.Popen("main.py", shell=True)





if __name__ == '__main__':
    main()
